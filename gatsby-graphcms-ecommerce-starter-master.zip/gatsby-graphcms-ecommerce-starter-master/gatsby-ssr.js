export { wrapPageElement, wrapRootElement } from './gatsby-browser';
